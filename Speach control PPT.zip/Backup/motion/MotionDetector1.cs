// Motion Detector
//
// Copyright � Andrew Kirillov, 2005-2006
// andrew.kirillov@gmail.com
//
namespace motion
{
	using System;
	using System.Drawing;
	using System.Drawing.Imaging;
    using System.Collections;
    using System.Runtime.InteropServices;
    using System.Reflection;
    using Tiger.Video.VFW;
    using System.Windows.Forms;
	using AForge.Imaging;
	using AForge.Imaging.Filters;

	/// <summary>
	/// MotionDetector1
	/// </summary>
    public class MotionDetector1 : IMotionDetector
    {
        private IFilter grayscaleFilter = new GrayscaleBT709();
        private Difference differenceFilter = new Difference();
        private Threshold thresholdFilter = new Threshold(15);
        private IFilter erosionFilter = new Erosion();
        private Merge mergeFilter = new Merge();

        private IFilter extrachChannel = new ExtractChannel(RGB.R);
        private ReplaceChannel replaceChannel = new ReplaceChannel(RGB.R, null);

        private Bitmap backgroundFrame;
        private BitmapData bitmapData;

        private FiltersSequence processingFilter = new FiltersSequence();

        private MainForm _mForm=new MainForm();
        private ArrayList points = new ArrayList();

        private int blankFrameCount = 0; // Blank frame count

        private Bitmap leftArrow, rightArrow, upArrow, downArrow, d1aArrow, d1bArrow, d2aArrow, d2bArrow, question;
        private Bitmap lastGesture;

        private bool drawGesture = false;


        public string slideName;

        private bool calculateMotionLevel = false;
        private int width;	// image width
        private int height;	// image height
        private int pixelsChanged;

        // Get a handle to an application window.
        [DllImport("USER32.DLL")]
        private static extern IntPtr FindWindow(string lpClassName,
            string lpWindowName);

        // Activate an application window.
        [DllImport("USER32.DLL")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);


        private class Beeper
        {
            [DllImport("Kernel32.dll")]
            public static extern bool Beep(UInt32 frequency, UInt32 duration);

            public static void RecognizedBeep()
            {
                Beep(2000, 50);
                System.Threading.Thread.Sleep(50);
                Beep(3000, 50);
            }

            public static void UnrecognizedBeep()
            {
                Beep(256, 200);
            }
        }

        // Motion level calculation - calculate or not motion level
        public bool MotionLevelCalculation
        {
            get { return calculateMotionLevel; }
            set { calculateMotionLevel = value; }
        }

        public void SlideName(string slidename)
        {
            slideName=slidename;
        }

        // Motion level - amount of changes in percents
        public double MotionLevel
        {
            get { return (double)pixelsChanged / (width * height); }
        }


        // Constructor
        public MotionDetector1()
        {
        }

        // Reset detector to initial state
        public void Reset()
        {
            if (backgroundFrame != null)
            {
                backgroundFrame.Dispose();
                backgroundFrame = null;
            }
        }

        // Process new frame
        public void ProcessFrame(ref Bitmap image)
        {
            
          
            Utility.UnsafeBitmap uBitmap = new Utility.UnsafeBitmap(image);
           
            bool brightnessFound = false;

            float brightest = 0;

            int xPos = 0, yPos = 0;

            uBitmap.LockBitmap();

            for (int y = 0; y < uBitmap.Bitmap.Height; y += 5)
            {
                for (int x = 0; x < uBitmap.Bitmap.Width; x += 5)
                {
                    byte red, green, blue;
                    red = uBitmap.GetPixel(x, y).red;
                    green = uBitmap.GetPixel(x, y).green;
                    blue = uBitmap.GetPixel(x, y).blue;

                    float brightness = (299 * red + 587 * green + 114 * blue) / 1000;

                    if (brightness > _mForm.threshold)
                    {
                        if (brightness > brightest)
                        {
                            brightest = brightness;
                            xPos = x;
                            yPos = y;
                            brightnessFound = true;
                        }
                    } // (brightness > _mForm.threshold)
                } // x loop
            } // y loop


            if (brightnessFound == true)
                points.Add(new Point(xPos, yPos));
            else
                blankFrameCount++;

            if (blankFrameCount < 5 && drawGesture == true)
            {
                Graphics dc = Graphics.FromImage((System.Drawing.Image)image);
                dc.DrawImage((System.Drawing.Image)lastGesture, 0, image.Height - 68);
                dc.Dispose();
            }
            else if (blankFrameCount > 5 && drawGesture == true)
            {
                drawGesture = false;
            }


            if (blankFrameCount > 5)
            {
                if (points.Count >= 2)
                {
                    Point[] pnts = (Point[])points.ToArray(typeof(Point));
                    string gesture = RecognizeMovement(pnts);
                   
                    drawGesture = true;


                    if ((gesture != "?") && (_mForm.pptControl == true))
                        ControlPowerPoint(gesture);

                }

                points.Clear();

                blankFrameCount = 0;
            }

            uBitmap.UnlockBitmap();
            uBitmap.Dispose();
        }


        // Code for controlling PowerPoint SlideShow
        private void ControlPowerPoint(string gesture)
        {
            IntPtr powerPointHandle = FindWindow(null, "PowerPoint Slide Show - ["+slideName+"]");
            
            // Verify that PPS is a running process.
            if (powerPointHandle == IntPtr.Zero)
            {
                System.Windows.Forms.MessageBox.Show("Slide Show not running");
                return;
            }

            switch (gesture)
            {
                case "LEFT":
                    SetForegroundWindow(powerPointHandle);
                    SendKeys.SendWait("p");
                    Beeper.RecognizedBeep();
                    break;

                case "RIGHT":
                    SetForegroundWindow(powerPointHandle);
                    SendKeys.SendWait("n");
                    Beeper.RecognizedBeep();
                    break;

                case "DIAGONAL2B":
                    SetForegroundWindow(powerPointHandle);
                    SendKeys.SendWait("n");
                    Beeper.RecognizedBeep();
                    break;

                case "DIAGONAL1A":
                    SetForegroundWindow(powerPointHandle);
                    SendKeys.SendWait("n");
                    Beeper.RecognizedBeep();
                    break;

                case "DIAGONAL1B":
                    SetForegroundWindow(powerPointHandle);
                    SendKeys.SendWait("P");
                    Beeper.RecognizedBeep();
                    break;

                case "DIAGONAL2A":
                    SetForegroundWindow(powerPointHandle);
                    SendKeys.SendWait("P");
                    Beeper.RecognizedBeep();
                    break;

                case "UP":
                    SetForegroundWindow(powerPointHandle);
                    SendKeys.SendWait("n");
                    Beeper.RecognizedBeep();
                    break;

                case "DOWN":
                    SetForegroundWindow(powerPointHandle);
                    SendKeys.SendWait("p");
                    Beeper.RecognizedBeep();
                    break;
            }
        }


        // Laser movement recognition code
        private string RecognizeMovement(Point[] pnts)
        {
            int x1, y1, x2, y2;
            int length = pnts.Length;

            x1 = pnts[0].X;
            y1 = pnts[0].Y;

            x2 = pnts[length - 1].X;
            y2 = pnts[length - 1].Y;

            int dx = Math.Abs(x2 - x1);
            int dy = Math.Abs(y2 - y1);
            bool diagonal = false;

            if (dx > dy)
            {
                if ((dy == 0) || ((dx / dy) >= 3))
                {
                    if ((x2 - x1) > 0)
                        return ("RIGHT");
                    else
                        return ("LEFT");
                }
                else
                    diagonal = true;
            }
            else if (dy > dx)
            {
                if ((dx == 0) || ((dy / dx) >= 3))
                {
                    if ((y2 - y1) > 0)
                        return ("DOWN");
                    else
                        return ("UP");
                }
                else
                    diagonal = true;

            }
            else
                diagonal = true;


            if (diagonal == true)
            {
                // Recognize diagonal type
                if ((x2 > x1) && (y2 > y1))
                {
                    return ("DIAGONAL1A");
                }
                else if ((x2 < x1) && (y2 < y1))
                {
                    return ("DIAGONAL1B");
                }
                else if ((x2 < x1) && (y2 > y1))
                {
                    return ("DIAGONAL2A");
                }
                else if ((x2 > x1) && (y2 < y1))
                {
                    return ("DIAGONAL2B");
                }
            }

            // If nothing else returned a value...
            return "?";
        }
    }
}
